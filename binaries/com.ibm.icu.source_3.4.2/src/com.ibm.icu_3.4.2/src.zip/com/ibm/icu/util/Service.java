/**
*******************************************************************************
* Copyright (C) 2005, International Business Machines Corporation and         *
* others. All Rights Reserved.                                                *
*******************************************************************************
*/
/*
package com.ibm.icu.util;

public class Service {
    public boolean   isAvailable();

    public String    getServiceName();
    public String    getServiceDisplayName(ULocale displayLocale);

    public String    getInstanceDisplayName(ULocale objectLocale);
    public String    getInstanceDisplayName(ULocale objectLocale, ULocale displayLocale);

    public Locale[]  getAvailableLocales();
    public ULocale[] getAvailableULocales();
    public String[]  getKeywords();
    public String[]  getKeywordValues(String keyword);
    public ULocale   getFunctionalEquivalent(String keyword, ULocale locID, boolean isAvailable[]);
    public ULocale   getFunctionalEquivalent(String keyword, ULocale locID);

   // JDK 1.5 APIs? 

    public T getInstance();
    public T getInstance(ULocale loc);
    
    // blue sky, to support NumberFormat.getCurrencyInstance, BreakIterator.getLineBreakInstance...
    public Enum<T>[] getSelectors();
    public T getInstance(Enum<T> selector);
    public T getInstance(Enum<T> selector, ULocale loc);

    // factory support
    public Object registerInstance(T instance, ULocale locale);
    public Object registerFactory(Factory<T> factory, ULocale locale);
    public boolean unregister(Object registryKey);
}
    */
