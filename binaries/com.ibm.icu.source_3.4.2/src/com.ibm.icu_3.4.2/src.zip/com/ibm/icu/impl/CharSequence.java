// dlf13 internal 1.3 compatibility only

package com.ibm.icu.impl;

/**
 * @internal
 */
public interface CharSequence {
    public char charAt(int index);
    public int length();
}
